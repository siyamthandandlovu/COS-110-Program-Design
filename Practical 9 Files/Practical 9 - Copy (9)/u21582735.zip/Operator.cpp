#ifndef __OPERATOR_CPP__
#define __OPERATOR_CPP__
#include <cstddef>
#include "Operator.h"

template<class T>
Operator<T>::Operator()
{
    
}

template<class T>
Operator<T>::~Operator()
{
    
}


#endif // __OPERATOR_CPP__