//File for all exception definitions
//See spec for inclusion strategy

#include <sstream>
