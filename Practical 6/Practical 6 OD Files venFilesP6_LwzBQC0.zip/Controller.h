//The Controller class

#include "Plane.h"
#include "Passenger.h"
#include "Cargo.h"

//See spec for inclusion strategy for templates
