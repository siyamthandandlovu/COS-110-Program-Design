//The Plane class

#include <vector>
#include "Exceptions.h"
#include "SecretCargo.h"

//See spec on inclusion strategy for templates
