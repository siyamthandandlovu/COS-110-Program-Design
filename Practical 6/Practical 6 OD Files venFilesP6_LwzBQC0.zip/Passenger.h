//The Passenger class

#include <sstream>
#include <string>
