//The SecretCargo class

