//Exception implementations
