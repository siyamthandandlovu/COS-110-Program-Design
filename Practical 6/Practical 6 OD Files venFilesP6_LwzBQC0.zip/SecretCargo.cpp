//The SecretCargo implementation file
