//The Cargo class

#include <string>
#include <sstream>
