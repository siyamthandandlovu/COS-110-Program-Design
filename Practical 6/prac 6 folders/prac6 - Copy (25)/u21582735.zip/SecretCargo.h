//u21582735 Siyamthanda Ndlovu
//The SecretCargo class

#ifndef SECRETCARGO_H 
#define SECRETCARGO_H 
class SecretCargo {
private:
double weight;

public:
SecretCargo( double w );
double getWeight() const;
};
#endif