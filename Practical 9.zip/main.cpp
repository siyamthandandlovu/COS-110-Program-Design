#include <iostream>
#include <string>
#include <sstream>

/*Do not remove this unless you want endless amounts of errors*/
#include "Operator.cpp"
#include "MinusOperator.cpp"
#include "MultiplyOperator.cpp"
#include "PlusOperator.cpp"
#include "Node.cpp"
#include "Stack.cpp"
#include "Calculator.cpp"

int main(){
    
}