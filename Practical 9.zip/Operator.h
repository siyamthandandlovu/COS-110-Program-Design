#ifndef OPERATOR_H
#define OPERATOR_H

#endif